const ext = typeof browser !== 'undefined' ? browser : chrome;

function saveToken(token, validity) {
  ext.storage.local.set({
    siac_token: token,
    siac_token_captured_at: Date.now(),
    siac_token_validity: validity || null
  });
}

function tryReadFromStorage() {
  try {
    const raw = localStorage.getItem('auth-profissionais');
    if (raw) {
      const parsed = JSON.parse(raw);
      const token = parsed?.sessionToken;
      const validity = parsed?.sessionValidity;
      if (token) {
        saveToken(token, validity);
        return true;
      }
    }
  } catch(e) {}
  return false;
}

// Interceptar fetch
const originalFetch = window.fetch;
window.fetch = async function(...args) {
  const response = await originalFetch.apply(this, args);
  try {
    let authHeader = null;
    if (args[1]?.headers) {
      const headers = args[1].headers;
      if (headers instanceof Headers) {
        authHeader = headers.get('Authorization') || headers.get('authorization');
      } else {
        authHeader = headers['Authorization'] || headers['authorization'];
      }
    }
    if (authHeader?.startsWith('Bearer ')) {
      tryReadFromStorage(); // relê o storage para obter sessionValidity atualizado
    }
  } catch(e) {}
  return response;
};

// Interceptar XMLHttpRequest
const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
XMLHttpRequest.prototype.setRequestHeader = function(header, value) {
  if (header.toLowerCase() === 'authorization' && value?.startsWith('Bearer ')) {
    tryReadFromStorage();
  }
  return originalSetRequestHeader.apply(this, arguments);
};

// Detectar logout: se a chave auth-profissionais for removida, limpar o token guardado
window.addEventListener('storage', (e) => {
  if (e.key === 'auth-profissionais' && !e.newValue) {
    ext.storage.local.remove(['siac_token', 'siac_token_captured_at', 'siac_token_validity']);
  }
});

tryReadFromStorage();
window.addEventListener('load', tryReadFromStorage);
