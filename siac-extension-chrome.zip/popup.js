const ext = typeof browser !== 'undefined' ? browser : chrome;

function formatTimeUntil(validity) {
  if (!validity) return '';
  const diffMs = validity - Date.now();
  if (diffMs <= 0) return 'Expirado';
  const mins = Math.floor(diffMs / 60000);
  const hours = Math.floor(mins / 60);
  const remMins = mins % 60;
  if (hours > 0) return `Expira em ${hours}h ${remMins}min`;
  return `Expira em ${remMins}min`;
}

async function refreshStatus() {
  const result = await ext.storage.local.get(['siac_token', 'siac_token_captured_at', 'siac_token_validity']);
  const statusEl = document.getElementById('token-status');
  const timeEl = document.getElementById('token-time');

  const now = Date.now();
  const expired = result.siac_token_validity && now > result.siac_token_validity;

  if (result.siac_token && !expired) {
    statusEl.textContent = 'Token disponível';
    statusEl.className = 'value ok';
    timeEl.textContent = formatTimeUntil(result.siac_token_validity);
  } else {
    if (expired) {
      await ext.storage.local.remove(['siac_token', 'siac_token_captured_at', 'siac_token_validity']);
    }
    statusEl.textContent = 'Sem token — faz login no portal SIAC';
    statusEl.className = 'value nok';
    timeEl.textContent = '';
  }
}

document.getElementById('btn-open').addEventListener('click', () => {
  ext.tabs.create({ url: 'https://portal.siac.pt' });
});

document.getElementById('btn-clear').addEventListener('click', async () => {
  await ext.storage.local.remove(['siac_token', 'siac_token_captured_at', 'siac_token_validity']);
  refreshStatus();
});

refreshStatus();
