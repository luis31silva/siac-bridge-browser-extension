/**
 * Bridge content script — injetado nas páginas da app (localhost / domínio de produção).
 * Escuta mensagens da página via window.postMessage e comunica com o background script.
 */
const ext = typeof browser !== 'undefined' ? browser : chrome;

window.addEventListener('message', (event) => {
  // Só aceitar mensagens da própria página
  if (event.source !== window) return;
  if (!event.data || event.data.type !== 'SIAC_TOKEN_BRIDGE_REQUEST') return;

  const { action, requestId } = event.data;

  // Enviar mensagem ao background script
  ext.runtime.sendMessage({ action }).then((response) => {
    window.postMessage({
      type: 'SIAC_TOKEN_BRIDGE_RESPONSE',
      requestId: requestId,
      payload: response
    }, '*');
  }).catch((err) => {
    window.postMessage({
      type: 'SIAC_TOKEN_BRIDGE_RESPONSE',
      requestId: requestId,
      payload: { success: false, error: err.message || 'Erro interno na extensão.' }
    }, '*');
  });
});

// Indicar à página que o bridge está disponível
window.postMessage({ type: 'SIAC_TOKEN_BRIDGE_READY' }, '*');
