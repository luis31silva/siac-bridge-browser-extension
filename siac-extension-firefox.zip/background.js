const ext = typeof browser !== 'undefined' ? browser : chrome;

// Handler para mensagens externas (Chrome externally_connectable) e internas (content scripts)
function handleTokenMessage(message, sender, sendResponse) {
  if (message.action === 'get_token') {
    ext.storage.local.get(['siac_token', 'siac_token_captured_at', 'siac_token_validity']).then((result) => {
      if (!result.siac_token) {
        sendResponse({ success: false, error: 'Sem token — faz login no portal SIAC primeiro.' });
        return;
      }

      const now = Date.now();
      if (result.siac_token_validity && now > result.siac_token_validity) {
        // token expirado — limpar e recusar
        ext.storage.local.remove(['siac_token', 'siac_token_captured_at', 'siac_token_validity']);
        sendResponse({ success: false, error: 'Token expirado — faz login novamente no portal SIAC.' });
        return;
      }

      sendResponse({
        success: true,
        token: result.siac_token,
        captured_at: result.siac_token_captured_at,
        valid_until: result.siac_token_validity
      });
    });
    return true;
  }

  if (message.action === 'clear_token') {
    ext.storage.local.remove(['siac_token', 'siac_token_captured_at', 'siac_token_validity']).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }
}

// Mensagens de content scripts (bridge.js) e popup
ext.runtime.onMessage.addListener(handleTokenMessage);

// Mensagens externas (Chrome com externally_connectable)
if (ext.runtime.onMessageExternal) {
  ext.runtime.onMessageExternal.addListener(handleTokenMessage);
}

// Verificação periódica: limpa o token sozinho quando expira, mesmo sem pedido da app
ext.alarms?.create('check-token-expiry', { periodInMinutes: 5 });
ext.alarms?.onAlarm.addListener((alarm) => {
  if (alarm.name === 'check-token-expiry') {
    ext.storage.local.get(['siac_token_validity']).then((result) => {
      if (result.siac_token_validity && Date.now() > result.siac_token_validity) {
        ext.storage.local.remove(['siac_token', 'siac_token_captured_at', 'siac_token_validity']);
      }
    });
  }
});
